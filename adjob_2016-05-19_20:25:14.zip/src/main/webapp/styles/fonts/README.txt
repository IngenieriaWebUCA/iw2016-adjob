Those are font files from the following projects:

Bootstrap
----------

* Version: v3.0.0
* License: Bootstrap is available under  license:
    Apache License, Version 2.0 (http://www.apache.org/licenses/LICENSE-2.0)
* Downloaded from: http://getbootstrap.com/

NOTE
-----

It's necessary to show the default Bootstrap icons.
Included by <span class="glyphicon glyphicon-check">
In use in ../webapp/WEB-INF/tags/datatables/table.tagx
