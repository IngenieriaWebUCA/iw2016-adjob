package es.uca.iw.reference;

public enum EstadoPeticionOferta {

    Recibida, Retirada, En_Estudio, Descartada, Aceptada
}
