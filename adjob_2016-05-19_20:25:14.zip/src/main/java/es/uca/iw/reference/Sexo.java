package es.uca.iw.reference;
import javax.persistence.Enumerated;

public enum Sexo {

    Mujer, Hombre, Otro;


}
