package es.uca.iw.reference;
import javax.persistence.Enumerated;

public enum TipoUsuario {

    Demandante, GestorETT, GestorEmpresa, Administrador, SuperAdministrador;

    /**
     */

}
