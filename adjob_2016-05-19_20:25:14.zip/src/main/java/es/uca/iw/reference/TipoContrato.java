package es.uca.iw.reference;

public enum TipoContrato {

    Indefinido, Temporal, HorasYservicios
}
