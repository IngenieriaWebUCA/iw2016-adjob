package es.uca.iw.reference;

public enum EstadoOferta {

    Espera, Activa, Detenida, Cancelada, Tramite, Resuelta
}
